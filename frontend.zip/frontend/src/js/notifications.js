function prepareSwitchNotificationToken(toggleID) {
    const toggle = document.getElementById('toggle-' + toggleID);

    if (toggle.checked) {
        Notification.requestPermission().then((permission) => {
            if (permission === 'granted') {
                switchNotificationToken(toggleID, true);
            } else {
                toggle.checked = false;
                document.getElementById('label-' + toggleID).style.cursor = 'not-allowed';
                document.getElementById('alert-notificationsPermissionIssue').style.display = 'flex';
            }
        });
    } else {
        switchNotificationToken(toggleID, false);
    }
}


//
//
function switchNotificationToken(toggleID) {
    if (document.getElementById('toggle-' + toggleID).checked) {
        Notification.requestPermission()
            .then((permission) => {
            if (permission === 'granted') {
                navigator.serviceWorker.ready.then((sw) => {
                    sw.pushManager.subscribe({
                        userVisibleOnly: true,
                        applicationServerKey: "BPmY3aRTv3WMzUk87saQ_ecjhzlhKq8FtdX9j-_dJuwCnePGRgXSBRlhgEnmgNTUvgKF6Xoo5zqcd5ZSPXD3Bt8"
                    }).then(async (subscription) => {
                        if ((await fetchServer('notificationToken', JSON.stringify(subscription))).success === true) {
                            Array.from(document.getElementsByClassName('notification-setting-hidden')).forEach((element) => {
                                element.classList.remove('notification-setting-hidden')
                                element.classList.add('notification-setting')
                            });
                        }
                    });
                });
            } else {
                document.getElementById('toggle-' + toggleID).checked = false
                document.getElementById('label-' + toggleID).style.cursor = 'not-allowed';
                document.getElementById('alert-notificationsPermissionIssue').style.display = 'flex';
            }
        })
    } else {
        fetchServer('notificationToken', null);
        Array.from(document.getElementsByClassName('notification-setting')).forEach((element) => {
            element.classList.remove('notification-setting')
            element.classList.add('notification-setting-hidden')
        });
    }
}

async function switchAccountParam(toggleID) {
    const object = document.getElementById('toggle-' + toggleID)
    console.log(toggleID)
    if (object.type === 'time') {
        console.log(await fetchServer(toggleID, object.value, 'fetch'))
    } else {
        if (object.checked) {
            console.log(await fetchServer(toggleID, 1, 'fetch'));
        } else {
            console.log(await fetchServer(toggleID, 0, 'fetch'));
        }
    }
}


document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('apple-notification-instruction')){
        if (isAppleDevice()){
            document.getElementById('apple-notification-instruction').hidden = false
        }
    }
});